package com.cdk.test.service;

public enum CustomerType {

	REGULAR, PREMIMUM

}
